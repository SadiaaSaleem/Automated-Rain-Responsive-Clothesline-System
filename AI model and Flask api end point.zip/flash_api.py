from flask import Flask, request, jsonify
import numpy as np
import joblib
import pandas as pd
from datetime import datetime, timedelta

app = Flask(__name__)

# Load the trained model
try:
    model = joblib.load('rain_model.joblib')
    print("Model loaded successfully")
except:
    print("No model found. Using fallback prediction method.")
    model = None


def parse_duration(duration_str):
    """Convert duration string (e.g., '1m 19s') to minutes"""
    parts = duration_str.split()
    total_minutes = 0
    for part in parts:
        if 'm' in part:
            total_minutes += int(part.replace('m', ''))
        elif 's' in part:
            total_minutes += int(part.replace('s', '')) / 60
    return total_minutes


def predict_rain_duration(intensity, current_duration):
    """Predict remaining rain duration using the trained model"""
    if model is not None:
        # Use the trained model
        features = pd.DataFrame([[intensity, current_duration]], columns=['intensity', 'current_duration'])
        predicted_total = model.predict(features)[0]
        predicted_remaining = max(0, predicted_total - current_duration)
    else:
        # Fallback to simple prediction
        if intensity > 80:  # Heavy rain
            predicted_remaining = 30
        elif intensity > 50:  # Moderate rain
            predicted_remaining = 20
        elif intensity > 20:  # Light rain
            predicted_remaining = 10
        else:  # Very light rain
            predicted_remaining = 5

    return round(predicted_remaining, 1)


@app.route('/ai-predict', methods=['POST'])
def predict():
    data = request.json
    intensity = float(data['rain_intensity'])
    duration = data['duration']

    # Convert duration to minutes
    current_duration = parse_duration(duration)

    # Get prediction
    predicted_remaining = predict_rain_duration(intensity, current_duration)

    # Calculate confidence based on how long it's been raining
    confidence = 100

    # Reduce confidence based on how long it's been raining
    confidence -= min(30, current_duration * 2)

    # Ensure confidence is between 50 and 100
    confidence = max(50, min(100, confidence))

    return jsonify({
        'predicted_remaining_minutes': predicted_remaining,
        'confidence': f"{round(confidence)}%",
        'current_intensity': f"{intensity}%",
        'current_duration': duration
    })


if __name__ == '__main__':
    app.run(port=5000)