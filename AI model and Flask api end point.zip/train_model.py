import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import joblib
import pandas as pd


def generate_mock_data(n_samples=1000):
    """Generate mock rain data for training"""
    np.random.seed(42)

    # Generate mock data
    data = []

    for _ in range(n_samples):
        # Generate random intensity (0-100%)
        intensity = np.random.uniform(0, 100)

        # Generate duration based on intensity patterns
        if intensity > 80:  # Heavy rain
            duration = np.random.normal(45, 10)  # 45 minutes ± 10
        elif intensity > 50:  # Moderate rain
            duration = np.random.normal(30, 8)  # 30 minutes ± 8
        elif intensity > 20:  # Light rain
            duration = np.random.normal(15, 5)  # 15 minutes ± 5
        else:  # Very light rain
            duration = np.random.normal(5, 2)  # 5 minutes ± 2

        # Add some noise to make it more realistic
        duration = max(1, duration + np.random.normal(0, 2))

        # Generate current duration (up to 80% of total duration)
        current_duration = np.random.uniform(0, duration * 0.8)

        data.append({
            'intensity': intensity,
            'current_duration': current_duration,
            'total_duration': duration
        })

    return pd.DataFrame(data)


def train_model():
    """Train the rain prediction model"""
    # Generate mock data
    print("Generating mock data...")
    data = generate_mock_data()

    # Prepare features and target
    X = data[['intensity', 'current_duration']]
    y = data['total_duration']

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train model
    print("Training model...")
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        random_state=42
    )
    model.fit(X_train, y_train)

    # Evaluate model
    train_score = model.score(X_train, y_train)
    test_score = model.score(X_test, y_test)
    print(f"Training R² score: {train_score:.3f}")
    print(f"Testing R² score: {test_score:.3f}")

    # Save model
    print("Saving model...")
    joblib.dump(model, 'rain_model.joblib')
    print("Model saved as 'rain_duration_model.joblib'")

    return model


if __name__ == '__main__':
    train_model()