const mqtt = require('mqtt');
const express = require('express');
const cors = require('cors');

const MQTT_HOST = 'd6c72beeebee45e0a6635b1c32db3a11.s1.eu.hivemq.cloud';
const MQTT_PORT = 8883;
const MQTT_USERNAME = 'hivemq.webclient.1746980014941';
const MQTT_PASSWORD = 'l25>6hAN3fKw@WB$;gpX';
const MQTT_TOPIC = 'home/rainSensor/status';

let latestStatus = null;

// MQTT connection options
const options = {
  host: MQTT_HOST,
  port: MQTT_PORT,
  protocol: 'mqtts',
  username: MQTT_USERNAME,
  password: MQTT_PASSWORD,
};

const client = mqtt.connect(options);

client.on('connect', () => {
  console.log('Connected to HiveMQ Cloud via MQTT');
  client.subscribe(MQTT_TOPIC, (err) => {
    if (err) {
      console.error('Failed to subscribe:', err);
    } else {
      console.log('Subscribed to', MQTT_TOPIC);
    }
  });
});

client.on('message', (topic, message) => {
  if (topic === MQTT_TOPIC) {
    latestStatus = message.toString();
    console.log('Received status:', latestStatus);
  }
});

client.on('error', (err) => {
  console.error('MQTT error:', err);
});

// Express server
const app = express();
app.use(cors());

app.get('/status', (req, res) => {
  res.json({ status: latestStatus });
});

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
}); 