import RainMonitor from './components/RainMonitor'
import './App.css'

function App() {
  return (
    <div className="App">
      <RainMonitor />
    </div>
  )
}

export default App
