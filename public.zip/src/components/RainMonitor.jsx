import { useState, useEffect } from 'react';
import { Box, Card, Typography, CircularProgress } from '@mui/material';
import axios from 'axios';

const BACKEND_URL = 'http://localhost:4000/status';

const RainMonitor = () => {
  const [isRaining, setIsRaining] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await axios.get(BACKEND_URL);
        const status = res.data.status;
        if (status === 'Raining') {
          setIsRaining(true);
          getRainPrediction();
        } else if (status === 'Dry') {
          setIsRaining(false);
          setPrediction(null);
        } else {
          setIsRaining(null);
        }
        setLoading(false);
      } catch (err) {
        setIsRaining(null);
        setLoading(false);
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 3000); // poll every 3 seconds
    return () => clearInterval(interval);
  }, []);

  const getRainPrediction = () => {
    setPrediction({
      duration: '2-3 hours',
      confidence: '75%',
    });
  };

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#f5f5f5',
      }}
    >
      <Card
        sx={{
          p: 4,
          maxWidth: 400,
          width: '100%',
          textAlign: 'center',
          boxShadow: 3,
        }}
      >
        <Typography variant="h4" gutterBottom>
          Rain Monitor
        </Typography>
        {loading ? (
          <CircularProgress />
        ) : (
          <>
            <Typography variant="h5" sx={{ mb: 2 }}>
              Status:{' '}
              {isRaining === null
                ? 'Unknown'
                : isRaining
                ? 'Raining'
                : 'Dry'}
            </Typography>
            {isRaining && prediction && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="h6" color="primary">
                  Rain Prediction
                </Typography>
                <Typography>
                  Expected Duration: {prediction.duration}
                </Typography>
                <Typography>
                  Confidence: {prediction.confidence}
                </Typography>
              </Box>
            )}
          </>
        )}
      </Card>
    </Box>
  );
};

export default RainMonitor; 